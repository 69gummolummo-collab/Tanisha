package com.example.vacuumtube

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var lastBack = 0L

    companion object {
        private const val START_URL = "https://www.youtube.com/tv"

        // Leanback only serves its UI to TV/console user agents.
        // If this stops working, swap in another TV UA string.
        private const val TV_UA =
            "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 " +
            "(KHTML, like Gecko) Version/15.0 Safari/605.1.15"

        // Android media keys -> the keyCodes Leanback listens for
        private val MEDIA_KEYS = mapOf(
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE to 179,
            KeyEvent.KEYCODE_MEDIA_PLAY to 415,
            KeyEvent.KEYCODE_MEDIA_PAUSE to 19,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD to 417,
            KeyEvent.KEYCODE_MEDIA_REWIND to 412,
            KeyEvent.KEYCODE_MEDIA_NEXT to 176,
            KeyEvent.KEYCODE_MEDIA_PREVIOUS to 177,
            KeyEvent.KEYCODE_MEDIA_STOP to 178
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isFocusableInTouchMode = true
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                userAgentString = TV_UA
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            CookieManager.getInstance().setAcceptCookie(true)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    injectScript(view)
                }
            }
        }
        setContentView(web)
        hideSystemUi()
        web.loadUrl(START_URL)
        web.requestFocus()
    }

    private fun injectScript(view: WebView) {
        val js = assets.open("inject.js").bufferedReader().use { it.readText() }
        view.evaluateJavascript(js, null)
    }

    /** Fire a synthetic key press into the page (Leanback reads keyCode). */
    private fun sendKey(code: Int) {
        val js = """
            (function(c){
              ['keydown','keyup'].forEach(function(t){
                var e = new KeyboardEvent(t,{bubbles:true,cancelable:true});
                Object.defineProperty(e,'keyCode',{get:function(){return c}});
                Object.defineProperty(e,'which',{get:function(){return c}});
                (document.activeElement||document.body).dispatchEvent(e);
              });
            })($code);
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    // D-pad arrows / Enter / Select are forwarded by WebView natively as
    // keyCodes 37-40 and 13, which is exactly what Leanback expects.
    // Media keys need manual mapping.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        MEDIA_KEYS[keyCode]?.let {
            if (event.repeatCount == 0) sendKey(it)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Back = Escape in Leanback. Press back twice within 2s to exit.
        val now = SystemClock.elapsedRealtime()
        if (now - lastBack < 2000) {
            finish()
        } else {
            lastBack = now
            sendKey(27)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
