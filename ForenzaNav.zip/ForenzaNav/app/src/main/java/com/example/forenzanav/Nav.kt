package com.example.forenzanav

import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.util.GeoPoint
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.cos
import kotlin.math.hypot

/** A maneuver (text + where it happens) and the length of the road that follows it. */
data class Step(val text: String, val loc: GeoPoint, val dist: Double)

class Route(val pts: List<GeoPoint>, val steps: List<Step>, val dist: Double, val dur: Double)

object Nav {

    private const val UA = "ForenzaNav/1.0 (hobby Android app)"

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 10000
        c.readTimeout = 20000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Free-text place search via OpenStreetMap Nominatim, biased toward the current position. */
    fun geocode(query: String, near: Location?): GeoPoint? {
        var url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" +
            URLEncoder.encode(query, "UTF-8")
        if (near != null) {
            val l = near.longitude - 0.6; val r = near.longitude + 0.6
            val t = near.latitude + 0.6; val b = near.latitude - 0.6
            url += "&viewbox=$l,$t,$r,$b"
        }
        val arr = JSONArray(httpGet(url))
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return GeoPoint(o.getString("lat").toDouble(), o.getString("lon").toDouble())
    }

    /** Driving route via the public OSRM demo server. */
    fun route(from: GeoPoint, to: GeoPoint): Route? {
        val url = "https://router.project-osrm.org/route/v1/driving/" +
            "${from.longitude},${from.latitude};${to.longitude},${to.latitude}" +
            "?overview=full&geometries=geojson&steps=true"
        val j = JSONObject(httpGet(url))
        if (j.optString("code") != "Ok") return null
        val r = j.getJSONArray("routes").getJSONObject(0)

        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val pts = List(coords.length()) {
            val c = coords.getJSONArray(it)
            GeoPoint(c.getDouble(1), c.getDouble(0))
        }

        val steps = ArrayList<Step>()
        val legSteps = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps")
        for (i in 0 until legSteps.length()) {
            val s = legSteps.getJSONObject(i)
            val m = s.getJSONObject("maneuver")
            val ll = m.getJSONArray("location")
            steps.add(
                Step(
                    describe(m.optString("type"), m.optString("modifier"), s.optString("name"), m.optInt("exit", 0)),
                    GeoPoint(ll.getDouble(1), ll.getDouble(0)),
                    s.getDouble("distance")
                )
            )
        }
        return Route(pts, steps, r.getDouble("distance"), r.getDouble("duration"))
    }

    private fun ordinal(n: Int) = when (n) { 1 -> "1st"; 2 -> "2nd"; 3 -> "3rd"; else -> "${n}th" }

    private fun dir(mod: String) = when (mod) {
        "slight left" -> "left"
        "slight right" -> "right"
        "sharp left" -> "left"
        "sharp right" -> "right"
        "" -> "ahead"
        else -> mod
    }

    private fun describe(type: String, mod: String, name: String, exit: Int): String {
        val onto = if (name.isNotBlank()) " onto $name" else ""
        val on = if (name.isNotBlank()) " on $name" else ""
        return when (type) {
            "arrive" -> "Arrive at your destination"
            "depart" -> "Head out$on"
            "roundabout", "rotary", "roundabout turn", "exit roundabout", "exit rotary" ->
                if (exit > 0) "At the roundabout, take the ${ordinal(exit)} exit$onto"
                else "Enter the roundabout$onto"
            "merge" -> "Merge ${dir(mod)}$onto"
            "on ramp" -> "Take the ramp ${dir(mod)}$onto"
            "off ramp" -> "Take the exit ${dir(mod)}$onto"
            "fork" -> "Keep ${dir(mod)}$onto"
            else -> when (mod) {
                "straight", "" -> "Continue straight$on"
                "uturn" -> "Make a U-turn$on"
                "slight left" -> "Bear left$onto"
                "slight right" -> "Bear right$onto"
                "sharp left" -> "Sharp left$onto"
                "sharp right" -> "Sharp right$onto"
                else -> "Turn $mod$onto"
            }
        }
    }

    fun dist(a: GeoPoint, b: GeoPoint): Double {
        val out = FloatArray(1)
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, out)
        return out[0].toDouble()
    }

    /** Shortest distance (meters) from p to the route polyline. */
    fun distanceToRoute(p: GeoPoint, pts: List<GeoPoint>): Double {
        val kx = 111320.0 * cos(Math.toRadians(p.latitude))
        val ky = 110540.0
        var best = Double.MAX_VALUE
        for (i in 0 until pts.size - 1) {
            val ax = (pts[i].longitude - p.longitude) * kx
            val ay = (pts[i].latitude - p.latitude) * ky
            val bx = (pts[i + 1].longitude - p.longitude) * kx
            val by = (pts[i + 1].latitude - p.latitude) * ky
            val dx = bx - ax; val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
            val d = hypot(ax + t * dx, ay + t * dy)
            if (d < best) best = d
        }
        return best
    }
}
