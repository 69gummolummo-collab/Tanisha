package com.example.forenzanav

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Top-down vehicle marker, always pointing up (the map rotates under it).
 * morph = 0 -> dark blue Suzuki Forenza, morph = 1 -> silver Pegasus with wings spread.
 * Everything is drawn from vector paths in "units": 1 unit = view size / 5.6.
 */
class CarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var morph: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private fun fill(c: Canvas, color: Int) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    private fun stroke(c: Canvas, color: Int, w: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w
        c.drawPath(path, p)
    }

    private fun poly(vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
        path.close()
    }

    private fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        rect.set(l, t, r, b)
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        c.drawOval(rect, p)
    }

    private fun rrect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        rect.set(l, t, r, b)
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        c.drawRoundRect(rect, rad, rad, p)
    }

    override fun onDraw(c: Canvas) {
        val u = min(width, height) / 5.6f
        val t = morph
        c.save()
        c.translate(width / 2f, height / 2f)
        c.scale(u, u)

        if (t > 0f) drawPegasus(c, t)

        if (t < 1f) {
            val s = 1f - 0.3f * t
            c.save()
            c.scale(s, s)
            val layer = c.saveLayerAlpha(-4f, -4f, 4f, 4f, (255 * (1f - t)).toInt())
            drawForenza(c)
            c.restoreToCount(layer)
            c.restore()
        }
        c.restore()
    }

    // ---------------------------------------------------------------- Forenza
    private fun drawForenza(c: Canvas) {
        val body = 0xFF0B2559.toInt()
        val glass = 0xFF8FB4D8.toInt()

        rrect(c, -0.62f, -1.25f, 0.72f, 1.45f, 0.4f, 0x44000000)          // shadow

        for (y in floatArrayOf(-0.95f, 0.6f)) {                              // wheels
            rrect(c, -0.6f, y, -0.46f, y + 0.4f, 0.05f, 0xFF111111.toInt())
            rrect(c, 0.46f, y, 0.6f, y + 0.4f, 0.05f, 0xFF111111.toInt())
        }
        rrect(c, -0.62f, -0.5f, -0.48f, -0.3f, 0.05f, body)                 // mirrors
        rrect(c, 0.48f, -0.5f, 0.62f, -0.3f, 0.05f, body)

        path.reset()                                                          // body shell
        path.moveTo(-0.34f, -1.3f); path.lineTo(0.34f, -1.3f)
        path.quadTo(0.5f, -1.25f, 0.5f, -1.0f); path.lineTo(0.5f, 1.0f)
        path.quadTo(0.5f, 1.3f, 0.3f, 1.3f); path.lineTo(-0.3f, 1.3f)
        path.quadTo(-0.5f, 1.3f, -0.5f, 1.0f); path.lineTo(-0.5f, -1.0f)
        path.quadTo(-0.5f, -1.25f, -0.34f, -1.3f); path.close()
        fill(c, body)
        stroke(c, 0xFF050F2B.toInt(), 0.03f)

        poly(-0.34f, -1.28f, 0.34f, -1.28f, 0.44f, -0.5f, -0.44f, -0.5f)    // hood sheen
        fill(c, 0xFF14408F.toInt())
        poly(-0.4f, -0.5f, 0.4f, -0.5f, 0.46f, -0.1f, -0.46f, -0.1f)        // windshield
        fill(c, glass)
        rrect(c, -0.44f, -0.1f, 0.44f, 0.5f, 0.1f, 0xFF0F2F70.toInt())      // roof
        poly(-0.44f, 0.5f, 0.44f, 0.5f, 0.38f, 0.85f, -0.38f, 0.85f)        // rear glass
        fill(c, 0xFF6F93B8.toInt())

        rrect(c, -0.44f, -1.29f, -0.2f, -1.2f, 0.04f, 0xFFFFF4C2.toInt())   // headlights
        rrect(c, 0.2f, -1.29f, 0.44f, -1.2f, 0.04f, 0xFFFFF4C2.toInt())
        rrect(c, -0.44f, 1.22f, -0.24f, 1.3f, 0.03f, 0xFFE53935.toInt())    // tail lights
        rrect(c, 0.24f, 1.22f, 0.44f, 1.3f, 0.03f, 0xFFE53935.toInt())
    }

    // ---------------------------------------------------------------- Pegasus
    private fun drawPegasus(c: Canvas, t: Float) {
        val layer = c.saveLayerAlpha(-4f, -4f, 4f, 4f, (255 * t).toInt())
        val spread = max(0.05f, t)

        // glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, 2.8f, intArrayOf(0x66BFD9FF, 0x00BFD9FF), null, Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, 2.8f, p)
        p.shader = null

        // tail
        path.reset()
        path.moveTo(-0.15f, 0.8f)
        path.cubicTo(-0.6f, 1.3f, 0.5f, 1.5f, -0.1f, 2.2f)
        path.cubicTo(0.9f, 1.6f, 0.5f, 1.2f, 0.15f, 0.8f)
        path.close()
        fill(c, 0xFFC9D3E6.toInt()); stroke(c, 0xFF8E98A8.toInt(), 0.03f)

        // wings (x scaled by spread so they unfold from the body)
        for (side in floatArrayOf(-1f, 1f)) {
            c.save()
            c.scale(side * spread, 1f)
            path.reset()
            path.moveTo(0.25f, -0.45f)
            path.cubicTo(1.0f, -1.0f, 1.9f, -1.1f, 2.7f, -0.6f)
            path.lineTo(2.35f, -0.4f); path.lineTo(2.6f, -0.05f); path.lineTo(2.1f, -0.1f)
            path.lineTo(2.3f, 0.3f); path.lineTo(1.8f, 0.2f); path.lineTo(1.9f, 0.6f)
            path.lineTo(1.3f, 0.4f); path.lineTo(1.2f, 0.7f); path.lineTo(0.25f, 0.5f)
            path.close()
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, 0f, 2.7f, 0f, 0xFFF4F6FA.toInt(), 0xFFB9C3D3.toInt(), Shader.TileMode.CLAMP)
            c.drawPath(path, p)
            p.shader = null
            stroke(c, 0xFF8E98A8.toInt(), 0.03f)
            p.style = Paint.Style.STROKE; p.strokeWidth = 0.03f; p.color = 0xFF9AA5B8.toInt()
            c.drawLine(0.35f, 0f, 2.6f, -0.05f, p)
            c.drawLine(0.35f, 0.05f, 2.3f, 0.3f, p)
            c.drawLine(0.35f, 0.1f, 1.9f, 0.6f, p)
            c.restore()
        }

        // hooves tucked under body
        for (sx in floatArrayOf(-0.32f, 0.32f)) for (y in floatArrayOf(-0.3f, 0.6f))
            oval(c, sx - 0.1f, y - 0.1f, sx + 0.1f, y + 0.1f, 0xFFD5DBE6.toInt())

        // torso
        rect.set(-0.36f, -0.6f, 0.36f, 0.9f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(-0.36f, 0f, 0.36f, 0f,
            intArrayOf(0xFFAEB8C6.toInt(), 0xFFF7F9FC.toInt(), 0xFFAEB8C6.toInt()), null, Shader.TileMode.CLAMP)
        c.drawOval(rect, p)
        p.shader = null

        // neck, mane, head
        poly(-0.17f, -0.5f, 0.17f, -0.5f, 0.12f, -1.1f, -0.12f, -1.1f)
        fill(c, 0xFFE9EDF3.toInt())
        rrect(c, -0.05f, -1.1f, 0.05f, -0.45f, 0.05f, 0xFF8FA8D0.toInt())
        poly(-0.16f, -1.15f, -0.27f, -1.28f, -0.1f, -1.28f); fill(c, 0xFFE9EDF3.toInt())
        poly(0.16f, -1.15f, 0.27f, -1.28f, 0.1f, -1.28f); fill(c, 0xFFE9EDF3.toInt())
        oval(c, -0.17f, -1.55f, 0.17f, -1.0f, 0xFFF2F4F8.toInt())
        oval(c, -0.11f, -1.7f, 0.11f, -1.4f, 0xFFE3E8F0.toInt())
        oval(c, -0.13f, -1.38f, -0.07f, -1.32f, 0xFF1B2433.toInt())
        oval(c, 0.07f, -1.38f, 0.13f, -1.32f, 0xFF1B2433.toInt())

        c.restoreToCount(layer)
    }
}
