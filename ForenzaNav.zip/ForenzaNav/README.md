# Forenza Nav

Garmin-style GPS navigation for Android (OpenStreetMap + OSRM routing).
A dark blue Suzuki Forenza is your position marker; above 35 mph it morphs into a
silver Pegasus (back to the car below 30 mph).

* Heading-up map that follows you, zooms out as you speed up
* Search a destination, turn-by-turn banner, voice prompts, rerouting, ETA
* Speed bubble (tap it to demo the morph at 50 mph without driving)
* Night mode toggle

## Get the APK without Android Studio
1. Create a free GitHub account and a new empty repository.
2. Upload every file in this folder (including the hidden `.github` folder) to it.
3. Open the repo's **Actions** tab -> **Build APK** -> wait ~5 minutes for the green check.
4. Open the finished run, download the **ForenzaNav-APK** artifact (a zip), unzip it.
5. Copy `app-debug.apk` to your phone, open it, and allow "install unknown apps".

## Android Studio
Open this folder, let Gradle sync, then Build > Build APK(s).
