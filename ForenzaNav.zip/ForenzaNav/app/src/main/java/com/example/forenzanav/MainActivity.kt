package com.example.forenzanav

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity(), LocationListener, TextToSpeech.OnInitListener {

    companion object {
        const val MORPH_UP_MPH = 35.0     // car -> Pegasus at/above this speed
        const val MORPH_DOWN_MPH = 30.0   // Pegasus -> car below this speed
        const val REQ_LOC = 1
    }

    private lateinit var map: MapView
    private lateinit var car: CarView
    private lateinit var speedView: TextView
    private lateinit var search: EditText
    private lateinit var banner: View
    private lateinit var instruction: TextView
    private lateinit var distanceView: TextView
    private lateinit var bottomBar: View
    private lateinit var etaView: TextView
    private lateinit var recenter: Button
    private lateinit var lm: LocationManager

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // location / camera
    private var locationStarted = false
    private var lastLoc: Location? = null
    private var lastGpsTime = 0L
    private var bearing = 0f
    private var follow = true
    private var camInit = false
    private var camLat = 0.0
    private var camLon = 0.0
    private var camBrg = 0f
    private var camZoom = 17.0
    private var camAnim: ValueAnimator? = null
    private var night = false

    // morph
    private var morphTarget = 0f
    private var morphAnim: ValueAnimator? = null
    private var demoMph = -1.0

    // navigation
    private var route: Route? = null
    private var dest: GeoPoint? = null
    private var routeLine: Polyline? = null
    private var destMarker: Marker? = null
    private var stepIdx = 0
    private var minDist = Double.MAX_VALUE
    private var said400 = false
    private var said80 = false
    private var offCount = 0
    private var rerouting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        car = findViewById(R.id.car)
        speedView = findViewById(R.id.speed)
        search = findViewById(R.id.search)
        banner = findViewById(R.id.banner)
        instruction = findViewById(R.id.instruction)
        distanceView = findViewById(R.id.distance)
        bottomBar = findViewById(R.id.bottomBar)
        etaView = findViewById(R.id.eta)
        recenter = findViewById(R.id.recenter)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.isTilesScaledToDpi = true
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.controller.setZoom(17.0)

        map.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_MOVE && follow) {
                follow = false
                recenter.visibility = View.VISIBLE
            }
            false
        }

        recenter.setOnClickListener {
            follow = true
            recenter.visibility = View.GONE
            lastLoc?.let { moveCamera(it.latitude, it.longitude, bearing, zoomFor(currentMph())) }
        }

        findViewById<Button>(R.id.night).setOnClickListener {
            night = !night
            map.overlayManager.tilesOverlay.setColorFilter(if (night) TilesOverlay.INVERT_COLORS else null)
            map.invalidate()
        }

        findViewById<Button>(R.id.cancel).setOnClickListener { clearRoute() }

        findViewById<Button>(R.id.go).setOnClickListener { doSearch() }
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }

        // Tap the speed bubble to demo the morph without driving: off -> 50 mph -> 0 mph -> off
        speedView.setOnClickListener {
            demoMph = when {
                demoMph < 0 -> 50.0
                demoMph > 0 -> 0.0
                else -> -1.0
            }
            Toast.makeText(
                this,
                if (demoMph < 0) "Demo off - using GPS speed" else "Demo speed ${demoMph.roundToInt()} mph",
                Toast.LENGTH_SHORT
            ).show()
            updateSpeed(currentMph())
        }

        tts = TextToSpeech(this, this)
        updateSpeed(0.0)

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQ_LOC
            )
        }
    }

    // ------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        map.onResume()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startLocation()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        locationStarted = false
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocation()
        } else {
            Toast.makeText(this, "Location permission is needed for navigation", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
    }

    // ------------------------------------------------------------ location
    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (locationStarted) return
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 1000L, 0f, this)
            }
            locationStarted = true
            val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) {
                lastLoc = last
                moveCamera(last.latitude, last.longitude, bearing, 17.0)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start GPS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onLocationChanged(loc: Location) {
        val isGps = loc.provider == LocationManager.GPS_PROVIDER
        val now = SystemClock.elapsedRealtime()
        if (isGps) lastGpsTime = now else if (now - lastGpsTime < 10000) return

        lastLoc = loc
        if (isGps && loc.hasBearing() && loc.hasSpeed() && loc.speed > 1.5f) bearing = loc.bearing

        val mph = currentMph()
        updateSpeed(mph)
        if (follow) moveCamera(loc.latitude, loc.longitude, bearing, zoomFor(mph))
        if (route != null) updateNavigation(loc)
    }

    @Deprecated("Required on older Android versions")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun currentMph(): Double {
        if (demoMph >= 0) return demoMph
        val l = lastLoc ?: return 0.0
        return if (l.hasSpeed()) l.speed * 2.23694 else 0.0
    }

    private fun zoomFor(mph: Double) = (18.0 - mph / 25.0).coerceIn(15.5, 18.0)

    // ------------------------------------------------------------ speed + morph
    private fun updateSpeed(mph: Double) {
        speedView.text = "${mph.roundToInt()}\nmph"
        val target = when {
            morphTarget == 0f && mph >= MORPH_UP_MPH -> 1f
            morphTarget == 1f && mph < MORPH_DOWN_MPH -> 0f
            else -> morphTarget
        }
        if (target != morphTarget) {
            morphTarget = target
            morphAnim?.cancel()
            val a = ValueAnimator.ofFloat(car.morph, target)
            a.duration = 900
            a.addUpdateListener { car.morph = it.animatedValue as Float }
            a.start()
            morphAnim = a
        }
    }

    // ------------------------------------------------------------ camera
    private fun applyCamera() {
        map.controller.setCenter(GeoPoint(camLat, camLon))
        map.mapOrientation = -camBrg
        map.controller.setZoom(camZoom)
    }

    private fun moveCamera(lat: Double, lon: Double, brg: Float, zoom: Double) {
        camAnim?.cancel()
        if (!camInit) {
            camInit = true
            camLat = lat; camLon = lon; camBrg = brg; camZoom = zoom
            applyCamera()
            return
        }
        val sLat = camLat; val sLon = camLon; val sBrg = camBrg; val sZoom = camZoom
        val d = ((brg - sBrg + 540f) % 360f) - 180f   // shortest rotation
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 900
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val f = it.animatedFraction
            camLat = sLat + (lat - sLat) * f
            camLon = sLon + (lon - sLon) * f
            camBrg = ((sBrg + d * f) + 360f) % 360f
            camZoom = sZoom + (zoom - sZoom) * f
            applyCamera()
        }
        a.start()
        camAnim = a
    }

    // ------------------------------------------------------------ search + routing
    private fun doSearch() {
        val q = search.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        val from = lastLoc
        if (from == null) {
            Toast.makeText(this, "Waiting for a GPS fix...", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Searching...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val to = Nav.geocode(q, from)
                if (to == null) {
                    runOnUiThread { Toast.makeText(this, "Place not found", Toast.LENGTH_LONG).show() }
                    return@Thread
                }
                val r = Nav.route(GeoPoint(from.latitude, from.longitude), to)
                runOnUiThread {
                    if (r == null) Toast.makeText(this, "No route found", Toast.LENGTH_LONG).show()
                    else startRoute(r, to)
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Network error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun startRoute(r: Route, to: GeoPoint) {
        clearRoute()
        route = r
        dest = to
        stepIdx = 0
        minDist = Double.MAX_VALUE
        said400 = false; said80 = false; offCount = 0

        val line = Polyline(map)
        line.setPoints(r.pts)
        line.outlinePaint.color = 0xFF1E88E5.toInt()
        line.outlinePaint.strokeWidth = 18f
        map.overlays.add(line)
        routeLine = line

        val m = Marker(map)
        m.position = to
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        map.overlays.add(m)
        destMarker = m
        map.invalidate()

        banner.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        follow = true
        recenter.visibility = View.GONE
        speak("Route started")
        lastLoc?.let { updateNavigation(it) }
    }

    private fun clearRoute() {
        route = null
        dest = null
        routeLine?.let { map.overlays.remove(it) }
        destMarker?.let { map.overlays.remove(it) }
        routeLine = null; destMarker = null
        banner.visibility = View.GONE
        bottomBar.visibility = View.GONE
        map.invalidate()
    }

    private fun updateNavigation(loc: Location) {
        val r = route ?: return
        val here = GeoPoint(loc.latitude, loc.longitude)

        // off-route -> reroute
        if (Nav.distanceToRoute(here, r.pts) > 60.0) offCount++ else offCount = 0
        if (offCount >= 3 && !rerouting) {
            rerouting = true
            offCount = 0
            speak("Rerouting")
            val to = dest
            Thread {
                try {
                    val nr = if (to != null) Nav.route(here, to) else null
                    runOnUiThread { if (nr != null && dest == to) startRoute(nr, to!!) }
                } catch (_: Exception) {
                } finally {
                    rerouting = false
                }
            }.start()
            return
        }

        val steps = r.steps
        if (stepIdx + 1 >= steps.size) return
        var next = steps[stepIdx + 1]
        var d = Nav.dist(here, next.loc)
        if (d < minDist) minDist = d

        val reach = max(30.0, loc.speed * 2.0)
        val passed = minDist < 80.0 && d > minDist + 15.0
        if (d < reach || passed) {
            if (stepIdx + 1 == steps.size - 1) {      // that was the arrival step
                speak("You have arrived")
                Toast.makeText(this, "You have arrived", Toast.LENGTH_LONG).show()
                clearRoute()
                return
            }
            stepIdx++
            minDist = Double.MAX_VALUE
            said400 = false; said80 = false
            next = steps[stepIdx + 1]
            d = Nav.dist(here, next.loc)
        }

        instruction.text = next.text
        distanceView.text = fmtDist(d)

        if (d < 450 && !said400) { said400 = true; speak("In ${fmtDist(d)}, ${next.text}") }
        if (d < 80 && !said80) { said80 = true; speak(next.text) }

        var remaining = d
        for (i in stepIdx + 1 until steps.size) remaining += steps[i].dist
        val secs = if (r.dist > 0) r.dur * remaining / r.dist else 0.0
        val eta = Calendar.getInstance().apply { add(Calendar.SECOND, secs.roundToInt()) }
        etaView.text = "${(secs / 60).roundToInt()} min  |  ${fmtDist(remaining)}  |  " +
            SimpleDateFormat("h:mm a", Locale.US).format(eta.time)
    }

    private fun fmtDist(m: Double): String {
        return if (m < 160) "${((m * 3.28084) / 10).roundToInt() * 10} ft"
        else String.format(Locale.US, "%.1f mi", m / 1609.344)
    }
}
