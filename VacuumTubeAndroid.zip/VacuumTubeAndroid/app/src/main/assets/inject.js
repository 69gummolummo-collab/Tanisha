// Runs after every page load. Port VacuumTube's page-injected features here
// (SponsorBlock, DeArrow, Return Dislikes, userstyles) from its src/ folder.
(function () {
  if (window.__vtInjected) return;
  window.__vtInjected = true;

  // Userstyle hook
  var style = document.createElement('style');
  style.textContent = '/* custom CSS here */';
  document.head.appendChild(style);

  // Basic ad skipper: clicks Leanback's "Skip" button when it appears
  setInterval(function () {
    var skip = document.querySelector('.ytlr-skip-button-renderer');
    if (skip) skip.click();
  }, 500);
})();
